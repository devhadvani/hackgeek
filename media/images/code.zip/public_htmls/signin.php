<?php
session_start();
$uname=$_POST["username"];
$pwd=$_POST["password"];

$conn=mysqli_connect("localhost","id20293035_milan","P&Gn#/#y1F=ByYC]","id20293035_mobileplanet");

        $sql ="SELECT * FROM signin WHERE username='$uname' AND password='$pwd'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) === 1) {
            $row = mysqli_fetch_assoc($result);
            if ($row['username'] === $uname && $row['password'] === $pwd)
             {
                
                $_SESSION["statussign"]="true";
                header("Location: index.php");
                exit();
            }else{
                header("location:signin.html");   
            }     
        }
        else{  
            echo "fail";
            header("location:signin.html");   
            exit();
        }
?>